ARQUIVO = "biblio.txt"

def adicinarlivro(livro):
    try:
        with open(ARQUIVO, "a", encoding="utf-8") as arq:
            arq.write(f"{livro['titulo']};{livro['autor']};{livro['genero']};{livro['disponibilidade']}\n")
    except Exception as e:
        print(f"Erro indefinido ao localizar arquivo - {e}")
    else:
        print("Livro adicionado com sucesso!")

def listarlivros():
    try:
        with open(ARQUIVO, "r", encoding="utf-8") as arq:
            biblio = arq.readlines()
            return biblio

    except FileNotFoundError:
            print("Nenhum livro cadastrado ainda.")
            return


def mostrarlivros():
        livros= listarlivros()
        if not livros:
            print("Nenhum livro cadastrado ainda.")
        else:
            print("\n📚---Livros da Laly---📚")
            for i, linha in enumerate(livros, 1):
                titulo, autor, genero, disponibilidade = linha.strip().split(";")
                print(f"{i}. Título: {titulo} | Autor: {autor} | Gêreno: {genero} |  Disponibilidade: {disponibilidade}")

def limparlivros():
     with open(ARQUIVO, "w", encoding="utf-8") as arq:
          arq.write("")


def removerlivros(selecao = 0):
    conteudo = listarlivros()    
    limparlivros()
    try:
        titulo, autor, genero, disponibilidade = conteudo[selecao -1].strip().split(";")
        if disponibilidade.lower() != "disponível":
            print(f"O livro '{titulo}' está alugado e não pode ser removido.")
        
        if disponibilidade == "Disponível":
            conteudo.pop(selecao - 1)
        else:
             print("livro alugado")

    except Exception as e:
            print(f"Erro indefinido converter seleção:{selecao} para inteiro - {e}")

    finally:
        for linha in conteudo:
             titulo, autor, genero, disponibilidade = linha.strip().split(";")
             livro = {
                "titulo" : titulo,
                "autor" : autor,
                "genero" : genero,
                "disponibilidade" : disponibilidade
            }
             adicinarlivro(livro)

def gravarlista(conteudo):
    with open(ARQUIVO, "w",encoding="utf-8") as arq:
        titulo, autor, genero, disponibilidade = conteudo.strip().split(";")
        arq.write (f"Título: {titulo} | Autor: {autor} | Gêreno: {genero} |  Disponibilidade: {disponibilidade}")
    mostrarlivros()

def alterarlivro(indice, novo_titulo=None, novo_autor=None, novo_genero=None):
    livros = listarlivros()
    if indice < 1 or indice > len(livros):
        print("Índice inválido.")
        return
    titulo, autor, genero, disponibilidade = livros[indice - 1].strip().split(";")
    novo = {
        "titulo": novo_titulo or titulo,
        "autor": novo_autor or autor,
        "genero": novo_genero or genero,
        "disponibilidade": disponibilidade
    }
    livros[indice - 1] = f"{novo['titulo']};{novo['autor']};{novo['genero']};{novo['disponibilidade']}\n"
    limparlivros()
    for linha in livros:
        t, a, g, d = linha.strip().split(";")
        adicinarlivro({"titulo": t, "autor": a, "genero": g, "disponibilidade": d})
    print("Livro alterado com sucesso!")

def alterardisponibilidade(indice, acao):
    livros = listarlivros()
    if indice < 1 or indice > len(livros):
        print("Índice inválido.")
        return
    titulo, autor, genero, disponibilidade = livros[indice - 1].strip().split(";")
    if acao == "alugar" and disponibilidade.lower() == "disponível":
        disponibilidade = "Alugado"
    elif acao == "devolver" and disponibilidade.lower() == "alugado":
        disponibilidade = "Disponível"
    else:
        print("Ação inválida ou estado atual do livro não permite essa operação.")
        return
    livros[indice - 1] = f"{titulo};{autor};{genero};{disponibilidade}\n"
    limparlivros()
    for linha in livros:
        t, a, g, d = linha.strip().split(";")
        adicinarlivro({"titulo": t, "autor": a, "genero": g, "disponibilidade": d})
    print("Disponibilidade atualizada com sucesso!")