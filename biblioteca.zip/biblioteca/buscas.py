ARQUIVO = "biblio.txt"

def buscarlivros(tag, usuario):
    try:
        with open(ARQUIVO, "r", encoding="utf-8") as arq:
            linhas = arq.readlines()
            encontrados = []
            for linha in linhas:
                titulo, autor, genero, disponibilidade = linha.strip().split(";")
                if tag == "titulo" and usuario.lower() in titulo.lower():
                    encontrados.append(linha)
                elif tag == "autor" and usuario.lower() in autor.lower():
                    encontrados.append(linha)
                elif tag == "genero" and usuario.lower() in genero.lower():
                    encontrados.append(linha)
            return encontrados
    except FileNotFoundError:
        return []
    
def exibirlivros():
    try:
        with open(ARQUIVO, "r", encoding="utf-8") as arq:
            livros = arq.readlines()
            if not livros:
                print("Nenhum livro cadastrado.")
                return
            for i, linha in enumerate(livros, 1):
                titulo, autor, genero, disponibilidade = linha.strip().split(";")
                print(f"{i}. Título: {titulo} | Autor: {autor} | Gênero: {genero} | Disponibilidade: {disponibilidade}")
    except FileNotFoundError:
        print("Arquivo de livros não encontrado.")