from funcoes import adicinarlivro, mostrarlivros, removerlivros, limparlivros, alterarlivro, alterardisponibilidade
from buscas import buscarlivros, exibirlivros

def menu():
    while True:
        print("\n📚=== Biblioteca da Laly ===📚")
        print("1 - Adicionar livros")
        print("2 - Mostrar Biblioteca")
        print("3 - Alugar Livro / Devolver livro")
        print("4 - Remover livro")
        print("5 - Buscar livro")
        print("6 - Alterar livros")
        print("0 - Sair")

        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            livro = {
                "titulo" : input("Digite o título: ").strip(),
                "autor" : input("Digite o autor: ").strip(),
                "genero" : input("Digite o gênero: ").strip(),
                "disponibilidade" : "Disponível"
            }
            
            
            adicinarlivro(livro)

        elif opcao == "2":
            mostrarlivros()
            
        elif opcao == "3":
            exibirlivros()
            indice = int(input("Digite o número do livro: "))
            acao = input("Digite 'alugar' ou 'devolver': ").lower()
            alterardisponibilidade(indice, acao)

        elif opcao == "4":
            mostrarlivros()
            selecao = int(input("Digite o número do livro: "))
            removerlivros(selecao)

        elif opcao == "5":
            tag = input("Buscar por (titulo/autor/genero): ").lower()
            usuario = input("Digite para buscar: ")
            resultados = buscarlivros(tag, usuario)
            if resultados:
                for linha in resultados:
                    print(linha.strip())
            else:
                print("Nenhum livro encontrado.")
            
        elif opcao == "6":
            exibirlivros()
            indice = int(input("Digite o número do livro a alterar: "))
            novo_titulo = input("Novo título (enter para manter): ")
            novo_autor = input("Novo autor (enter para manter): ")
            novo_genero = input("Novo gênero (enter para manter): ")
            alterarlivro(indice, novo_titulo or None, novo_autor or None, novo_genero or None)
        
        elif opcao == "0":
            print("Saindo da Biblioteca! Tchau Tchau!!!👋👋👋")
            break
        else:
            print("Opção inválida! Tente novamente.")

menu()